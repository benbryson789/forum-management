Features :
1. User signup
2.User Login
3.User Profile Update
4.User Change Password
5.User Manage Own Forum(Create,read,update,delete)
6.Forum List for publically
7.Comment user on Forum detail page

Technogy :
1. React for Frontend.
2.Firebase for backend.